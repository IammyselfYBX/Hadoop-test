package mapper测试;


public class Mapper {


	public static void main(String[] args) {
		// TODO Auto-generated method stub	

		long startTime = System.currentTimeMillis();
		Info info = new Info();
		System.out.println(info.id);
		System.out.println(info.url);
		info.type();
		long endTime = System.currentTimeMillis();
		System.out.println("程序运行时间： "+(endTime-startTime)+"ms");
		
	}

}
