package mapper测试;

public class SES {

	public int start;
	public int end;
	public double speed;
	
	public SES(int a,int b,double c) {
		start=a;
		end=b;
		speed=c;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub	

		
	}
	
}
