package mapper测试;

import java.io.*;
import java.math.BigDecimal;


public class Info {
    
	

	private double b1[];
	private int num=0;
	String url="";
	String id="";
	
	
	public Info() {

		SES a1[];
		String str="";
		int i=0;
		try {
			FileReader fr = new FileReader("text.txt");
			while((i=fr.read())!=-1) {
				str+=(char)i;
			}
			fr.close();

		}
		catch(FileNotFoundException fnfe) {
			System.out.println("没有找到文件");
			System.exit(0);
		}
		catch(IOException ioe) {
			System.out.println("文件读取错误");
			System.exit(0);
		}			
		char [] array = str.toCharArray();
		System.out.println(array);//---------------------------将字符串放入数组---------
		int a=0,b=0,c=0;
		String url="";
		String id="";
		for(a=1;a<array.length;a++) {
			if(array[a]!='*') {
				url+=array[a];
			}
			else {break;}
		}
		for(b=a+1;b<array.length;b++) {
			if(array[b]!='!') {
				id+=array[b];
			}
			else {break;}
		}
		
		
		int num=0;
		int x=0;
		for(c=b;c<array.length;c++) {
			if(array[c]=='!') {num++;}
		}
		num--;
        a1 = new SES[num];
        for(int w=0;w<num;w++) {
        	a1[w] = new SES(0,0,0);
        }//先计算数组个数，并初始化
        

        String data1="";
        String data2="";
        String data3="";
		int int1=0;
		int int2=0;
		double double3=0;
		for(x=0,c=b+1;x<num;x++) {
	        data1="";
			while(array[c]!='-') {
				data1+=array[c];
				c++;
	        }
			c++;
			data2="";
			while(array[c]!='-') {
				data2+=array[c];
				c++;
			}
			c++;
			data3="";
			while(array[c]!='!') {
				data3+=array[c];
				c++;
			}
			c++;
			int1 = Integer.parseInt(data1);
			int2 = Integer.parseInt(data2);
			double3 = Double.parseDouble(data3);
			System.out.println("第"+ x +"组数据:"+ data1 + "---" + data2 +"---" + data3);
			a1[x]= new SES(int1,int2,double3);					
		}
        
		System.out.println(url);//提取了网址URL
		System.out.println(id);//提取了id

	    int l=a1[a1.length-1].end;
        b1 = new double[l];

        for(int j=0;j<b1.length;j++) {
        	b1[j] = 1;//设置进度条数组每个元素的初值为1
        }

        for(int j=0;j<num;j++) {
        		int start=a1[j].start;
        		int end=a1[j].end;
        		double weight=(1/(a1[j].speed));
                BigDecimal bd = new BigDecimal(weight);
                /*setScale 第一个参数为保留位数 第二个参数为舍入机制
                 BigDecimal.ROUND_DOWN 表示不进位 
                 BigDecimal.ROUND_UP表示进位*/
                weight = bd.setScale(4, BigDecimal.ROUND_UP).doubleValue();
        		for(int k=start;k<end;k++) {b1[k]=b1[k]+weight;}
        		}
        System.out.println("完成");

	}
	
	public void type() {

		for(int i=0;i<num;i++) {
            BigDecimal b = new BigDecimal(b1[i]);
            /*setScale 第一个参数为保留位数 第二个参数为舍入机制
             BigDecimal.ROUND_DOWN 表示不进位 
             BigDecimal.ROUND_UP表示进位*/
            b1[i] = b.setScale(4, BigDecimal.ROUND_UP).doubleValue();
			System.out.println(i+":"+b1[i]);

		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub	

	}
	
}
